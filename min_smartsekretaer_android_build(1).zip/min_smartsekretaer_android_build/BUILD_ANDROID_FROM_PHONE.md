# Min Smartsekretær – Android APK

هذه النسخة مجهزة للبناء السحابي إلى Android APK فقط.

## من الهاتف فقط
1. أنشئ حسابًا في GitHub إن لم يكن لديك حساب.
2. أنشئ مستودعًا جديدًا (Repository) باسم `min-smartsekretaer`.
3. ارفع جميع ملفات هذا المشروع إلى المستودع.
4. افتح تبويب **Actions**.
5. اختر **Build Android APK** ثم **Run workflow**.
6. بعد انتهاء البناء، افتح نتيجة التشغيل ونزّل artifact باسم `min-smartsekretaer-android-apk`.
7. فك الضغط عن الملف ثم ثبّت `app-release.apk` على هاتف Android.

> ملاحظة: هذه البيئة لا تحتوي على Flutter/Dart، لذلك لم يتم إنتاج APK هنا. ملف GitHub Actions أعلاه يقوم بإنشاء ملفات Android اللازمة وتشغيل Flutter وبناء APK تلقائيًا على خادم Ubuntu.

## ملاحظات مهمة
- الهدف الحالي Android فقط.
- أول تشغيل قد يستغرق عدة دقائق بسبب تنزيل Flutter وحزم المشروع.
- قد يطلب Android صلاحيات الحركة والموقع والتقويم والإشعارات عند تشغيل التطبيق.
