# Min Smartsekretær v0.6

Denne versjonen kobler Kalender til systemkalenderen på Android/iPhone med `device_calendar_plus`.

## Funksjoner
- Les dagens avtaler fra systemkalenderen.
- Velg dato.
- Opprett ny avtale direkte fra appen.
- 15-minutters kalenderpåminnelse på nye avtaler.
- Trykk på en avtale for å åpne systemets kalenderredigering.

## Bygg
Krever Flutter/Dart som støtter Dart 3.12+. Kjør `flutter pub get` og deretter `flutter run`.

Android må be om kalenderrettigheter. iOS krever kalenderbeskrivelsene i Info.plist og Xcode/macOS for lokal bygging.


### v0.7 – Aktivitet
- Skritttelling via telefonens innebygde pedometersensor.
- GPS-posisjon med brukertillatelse.
- Åpne nåværende posisjon i Google Maps.
- Distanse beregnes foreløpig som 0,75 meter per skritt.
- Android krever ACTIVITY_RECOGNITION og posisjonstillatelser; iOS krever Motion/Location-beskrivelse.
