# Min Smartsekretær – Android build

Flutter source prepared for Android-only cloud build. The workflow in `.github/workflows/build-android.yml` creates the Android platform files and builds a release APK.
