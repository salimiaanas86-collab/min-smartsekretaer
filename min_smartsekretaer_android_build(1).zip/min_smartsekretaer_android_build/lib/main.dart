import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:device_calendar_plus/device_calendar_plus.dart';
import 'package:pedometer/pedometer.dart';
import 'package:geolocator/geolocator.dart';

final notificationService = NotificationService();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await notificationService.init();
  runApp(const MinSmartsekretaerApp());
}

class NotificationService {
  final FlutterLocalNotificationsPlugin plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz.initializeTimeZones();
    try {
      final zone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zone.name));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Europe/Oslo'));
    }

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    final ios = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    await plugin.initialize(
      const InitializationSettings(android: android, iOS: ios),
    );

    final androidImpl = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();
    await androidImpl?.requestExactAlarmsPermission();
    await plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  }

  Future<void> scheduleReminder({required int id, required String title, required DateTime time}) async {
    if (!time.isAfter(DateTime.now())) return;
    await plugin.zonedSchedule(
      id,
      'Min Smartsekretær',
      title,
      tz.TZDateTime.from(time, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'smartsekretaer_reminders',
          'Påminnelser',
          channelDescription: 'Personlige påminnelser',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancel(int id) => plugin.cancel(id);
}


class MinSmartsekretaerApp extends StatelessWidget {
  const MinSmartsekretaerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Min Smartsekretær',
    debugShowCheckedModeBanner: false,
    locale: const Locale('nb', 'NO'),
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int index = 0;
  final pages = const [HomePage(), EconomyPage(), TasksPage(), NotesPage(), MorePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (i) => setState(() => index = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Hjem'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Økonomi'),
        NavigationDestination(icon: Icon(Icons.task_alt), label: 'Oppgaver'),
        NavigationDestination(icon: Icon(Icons.note_alt_outlined), label: 'Notater'),
        NavigationDestination(icon: Icon(Icons.more_horiz), label: 'Mer'),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final today = DateFormat('EEEE d. MMMM', 'nb_NO').format(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: const Text('Min Smartsekretær')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('God dag 👋', style: Theme.of(context).textTheme.headlineMedium),
        Text(today), const SizedBox(height: 16),
        const DashboardCard(), const SizedBox(height: 12),
        _tile(context, Icons.notifications_none, 'Påminnelser', 'Opprett varsler med dato og klokkeslett', const RemindersPage()),
        _tile(context, Icons.calendar_month_outlined, 'Kalender', 'Avtaler og aktiviteter', const CalendarPage()),
        _tile(context, Icons.cloud_outlined, 'Vær', 'Oslo • Berlin • Chemnitz • Al-Khalil', const WeatherPage()),
        _tile(context, Icons.newspaper_outlined, 'Nyheter', 'Norge og Oslo', const NewsPage()),
        _tile(context, Icons.music_note_outlined, 'Musikk', 'Planlagt musikkavspilling', const MusicPage()),
        _tile(context, Icons.directions_walk_outlined, 'Aktivitet & tur', 'Steg, distanse og kart', const ActivityPage()),
      ]),
    );
  }
  Widget _tile(BuildContext context, IconData icon, String title, String sub, Widget page) => Card(
    child: ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(sub), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page))),
  );
}

class DashboardCard extends StatelessWidget {
  const DashboardCard({super.key});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('💰 Økonomi', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    const Text('Inntekt: 34 500 kr'), const Text('Utgifter: 33 500–34 500 kr'), const SizedBox(height: 6),
    Text('Forventet igjen: 0–1 000 kr', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
  ])));
}

class EconomyPage extends StatefulWidget { const EconomyPage({super.key}); @override State<EconomyPage> createState()=>_EconomyPageState(); }
class _EconomyPageState extends State<EconomyPage> {
  double income = 34500;
  final items = <String,double>{'🏠 Husleie':16500,'⚡ Strøm':3000,'🚌 Månedskort':400,'📱 Mobil':600,'👕 Klær':1000,'🍳 Frokost':3000,'🍽️ Middag':3000,'🚬 Sigaretter':2700,'🦷 Tannlege':300,'🏋️ Trening':500,'🎬 Kino':500};
  double parentsGift=2500;
  double get total=>items.values.fold(0,(a,b)=>a+b)+parentsGift;
  @override Widget build(BuildContext context){ final r=income-total; return Scaffold(appBar:AppBar(title:const Text('Økonomi')),floatingActionButton:FloatingActionButton.extended(onPressed:_addExpense,icon:const Icon(Icons.add),label:const Text('Ny utgift')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:ListTile(title:const Text('Inntekt'),trailing:Text('${income.toStringAsFixed(0)} kr'))),
    Card(child:ListTile(title:const Text('Totale utgifter'),trailing:Text('${total.toStringAsFixed(0)} kr'))),
    Card(child:ListTile(title:const Text('Igjen'),trailing:Text('${r.toStringAsFixed(0)} kr',style:TextStyle(fontWeight:FontWeight.bold,color:r<0?Colors.red:null)))),
    ...items.entries.map((e)=>ListTile(leading:const Icon(Icons.receipt_long_outlined),title:Text(e.key),trailing:Text('${e.value.toStringAsFixed(0)} kr'))),
    ListTile(leading:const Icon(Icons.card_giftcard_outlined),title:const Text('🎁 Gave til mamma og pappa'),subtitle:const Text('Budsjett 2 000–3 000 kr'),trailing:Text('${parentsGift.toStringAsFixed(0)} kr')),
  ])); }
  Future<void> _addExpense() async { final n=TextEditingController(),a=TextEditingController(); final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Ny utgift'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Navn')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Beløp'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Avbryt')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Lagre'))])); if(ok==true&&n.text.trim().isNotEmpty){setState(()=>items[n.text.trim()]=double.tryParse(a.text.replaceAll(',','.'))??0);}}
}

class TasksPage extends StatefulWidget { const TasksPage({super.key}); @override State<TasksPage> createState()=>_TasksPageState(); }
class _TasksPageState extends State<TasksPage>{ List<String> tasks=[]; bool loading=true; @override void initState(){super.initState();_load();} Future<void> _load()async{final p=await SharedPreferences.getInstance();setState((){tasks=p.getStringList('tasks')??[];loading=false;});} Future<void> _save()=>SharedPreferences.getInstance().then((p)=>p.setStringList('tasks',tasks));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Oppgaver')),floatingActionButton:FloatingActionButton(onPressed:_add,child:const Icon(Icons.add)),body:loading?const Center(child:CircularProgressIndicator()):tasks.isEmpty?const Center(child:Text('Ingen oppgaver ennå.')):ListView.builder(itemCount:tasks.length,itemBuilder:(_,i)=>CheckboxListTile(value:false,onChanged:(_){setState(()=>tasks.removeAt(i));_save();},title:Text(tasks[i]))));
  Future<void> _add()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Ny oppgave'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Oppgave')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Avbryt')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Lagre'))]));if(ok==true&&c.text.trim().isNotEmpty){setState(()=>tasks.add(c.text.trim()));_save();}}
}

class NotesPage extends StatefulWidget { const NotesPage({super.key}); @override State<NotesPage> createState()=>_NotesPageState(); }
class _NotesPageState extends State<NotesPage>{ List<String> notes=[]; bool loading=true; @override void initState(){super.initState();_load();} Future<void> _load()async{final p=await SharedPreferences.getInstance();setState((){notes=p.getStringList('notes')??[];loading=false;});} Future<void> _save()=>SharedPreferences.getInstance().then((p)=>p.setStringList('notes',notes));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Notater')),floatingActionButton:FloatingActionButton(onPressed:_add,child:const Icon(Icons.add)),body:loading?const Center(child:CircularProgressIndicator()):notes.isEmpty?const Center(child:Text('Ingen notater ennå.')):ListView(children:notes.asMap().entries.map((e)=>Card(child:ListTile(title:Text(e.value),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>notes.removeAt(e.key));_save();}))).toList()));
  Future<void> _add()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Nytt notat'),content:TextField(controller:c,maxLines:5,decoration:const InputDecoration(hintText:'Skriv notatet ditt')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Avbryt')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Lagre'))]));if(ok==true&&c.text.trim().isNotEmpty){setState(()=>notes.add(c.text.trim()));_save();}}
}

class Reminder { String title; DateTime time; bool done; int id; Reminder(this.title,this.time,{this.done=false,this.id=0}); Map<String,dynamic> toJson()=>{'title':title,'time':time.toIso8601String(),'done':done,'id':id}; static Reminder fromJson(Map<String,dynamic> j)=>Reminder(j['title'],DateTime.parse(j['time']),done:j['done']??false,id:j['id']??0); }
class RemindersPage extends StatefulWidget { const RemindersPage({super.key}); @override State<RemindersPage> createState()=>_RemindersPageState(); }
class _RemindersPageState extends State<RemindersPage>{ List<Reminder> reminders=[]; bool loading=true; @override void initState(){super.initState();_load();}
  Future<void> _load()async{final p=await SharedPreferences.getInstance();final raw=p.getString('reminders');setState((){reminders=raw==null?[]:(jsonDecode(raw) as List).map((x)=>Reminder.fromJson(Map<String,dynamic>.from(x))).toList()..sort((a,b)=>a.time.compareTo(b.time));loading=false;});}
  Future<void> _save()async{final p=await SharedPreferences.getInstance();await p.setString('reminders',jsonEncode(reminders.map((e)=>e.toJson()).toList()));}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Påminnelser')),floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.alarm_add),label:const Text('Ny påminnelse')),body:loading?const Center(child:CircularProgressIndicator()):reminders.isEmpty?const Center(child:Text('Ingen påminnelser. Trykk «Ny påminnelse».')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:reminders.length,itemBuilder:(_,i){final r=reminders[i];return Card(child:ListTile(leading:Icon(r.done?Icons.notifications_off:Icons.notifications_active),title:Text(r.title),subtitle:Text(DateFormat('EEE d. MMM • HH:mm','nb_NO').format(r.time)),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){final removed=reminders[i];setState(()=>reminders.removeAt(i));await notificationService.cancel(removed.id);_save();})));});
  Future<void> _add()async{final title=TextEditingController();DateTime selected=DateTime.now().add(const Duration(hours:1));final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(context,setLocal)=>AlertDialog(title:const Text('Ny påminnelse'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Hva skal jeg minne deg på?')),const SizedBox(height:12),ListTile(leading:const Icon(Icons.schedule),title:Text(DateFormat('d. MMMM yyyy • HH:mm','nb_NO').format(selected)),onTap:()async{final d=await showDatePicker(context:context,initialDate:selected,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)));if(d==null)return;final t=await showTimePicker(context:context,initialTime:TimeOfDay.fromDateTime(selected));if(t!=null)setLocal(()=>selected=DateTime(d.year,d.month,d.day,t.hour,t.minute));}})]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Avbryt')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Lagre'))]));if(ok==true&&title.text.trim().isNotEmpty){final id=DateTime.now().millisecondsSinceEpoch.remainder(2147483647);final reminder=Reminder(title.text.trim(),selected,id:id);await notificationService.scheduleReminder(id:id,title:reminder.title,time:reminder.time);setState((){reminders.add(reminder);reminders.sort((a,b)=>a.time.compareTo(b.time));});await _save();}}
}

class CalendarPage extends StatefulWidget{const CalendarPage({super.key});@override State<CalendarPage> createState()=>_CalendarPageState();}
class _CalendarPageState extends State<CalendarPage>{
  final DeviceCalendar _calendar=DeviceCalendar.instance;
  DateTime _selected=DateTime.now();
  List<Event> _events=[]; bool _loading=true; String? _error;
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{
    setState(()=>_loading=true);
    try{
      final status=await _calendar.requestPermissions();
      if(status!=CalendarPermissionStatus.granted){setState((){_error='Kalendertilgang er ikke gitt. Du kan gi tilgang i systeminnstillingene.';_loading=false;});return;}
      final start=DateTime(_selected.year,_selected.month,_selected.day);
      final end=start.add(const Duration(days:1));
      final result=await _calendar.listEvents(start,end);
      setState((){_events=result;_error=null;_loading=false;});
    }catch(e){setState((){_error='Kunne ikke lese kalenderen: $e';_loading=false;});}
  }
  Future<void> _addEvent()async{
    final title=TextEditingController();
    TimeOfDay startTime=TimeOfDay.now();
    TimeOfDay endTime=TimeOfDay(hour:(TimeOfDay.now().hour+1)%24,minute:TimeOfDay.now().minute);
    final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(context,setLocal)=>AlertDialog(title:const Text('Ny avtale'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Tittel')),ListTile(leading:const Icon(Icons.access_time),title:Text('Start'),subtitle:Text(startTime.format(context)),onTap:()async{final t=await showTimePicker(context:context,initialTime:startTime);if(t!=null)setLocal(()=>startTime=t);}),ListTile(leading:const Icon(Icons.schedule),title:Text('Slutt'),subtitle:Text(endTime.format(context)),onTap:()async{final t=await showTimePicker(context:context,initialTime:endTime);if(t!=null)setLocal(()=>endTime=t);})]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Avbryt')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Lagre'))])));
    if(ok!=true||title.text.trim().isEmpty)return;
    try{
      final start=DateTime(_selected.year,_selected.month,_selected.day,startTime.hour,startTime.minute);
      var end=DateTime(_selected.year,_selected.month,_selected.day,endTime.hour,endTime.minute);
      if(!end.isAfter(start))end=end.add(const Duration(hours:1));
      await _calendar.createEvent(title:title.text.trim(),startDate:start,endDate:end,reminders:const [Duration(minutes:15)]);
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Kunne ikke opprette avtalen: $e')));}
  }
  String _time(Event e){if(e.isAllDay)return 'Hele dagen';return '${DateFormat('HH:mm').format(e.startDate)}–${DateFormat('HH:mm').format(e.endDate)}';}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Kalender'),actions:[IconButton(onPressed:_load,icon:const Icon(Icons.refresh),tooltip:'Oppdater')]),floatingActionButton:FloatingActionButton.extended(onPressed:_addEvent,icon:const Icon(Icons.event_available),label:const Text('Ny avtale')),body:ListView(padding:const EdgeInsets.all(12),children:[Card(child:CalendarDatePicker(initialDate:_selected,firstDate:DateTime(2020),lastDate:DateTime(2035),onDateChanged:(d){setState(()=>_selected=d);_load();})),const SizedBox(height:8),if(_loading)const Center(child:Padding(padding:EdgeInsets.all(24),child:CircularProgressIndicator())) else if(_error!=null)Card(child:ListTile(leading:const Icon(Icons.info_outline),title:const Text('Kalendertilgang'),subtitle:Text(_error!))) else if(_events.isEmpty)const Card(child:ListTile(leading:Icon(Icons.event_busy),title:Text('Ingen avtaler'),subtitle:Text('Det er ingen avtaler denne dagen.'))) else ..._events.map((e)=>Card(child:ListTile(leading:const Icon(Icons.event),title:Text(e.title??'Uten tittel'),subtitle:Text(_time(e)),onTap:()async{try{await _calendar.showEventModal(e.instanceId,edit:true);}catch(_){}}))) ]));
}

class WeatherCityData {
  final String name;
  final String timezone;
  final List<DateTime> times;
  final List<double> temperatures;
  final List<int> precipitation;
  final List<int> codes;
  final List<double> wind;
  WeatherCityData({required this.name, required this.timezone, required this.times, required this.temperatures, required this.precipitation, required this.codes, required this.wind});
}

class WeatherService {
  static const cities = <String, Map<String, String>>{
    'Oslo': {'lat': '59.9139', 'lon': '10.7522', 'tz': 'Europe/Oslo'},
    'Berlin': {'lat': '52.5200', 'lon': '13.4050', 'tz': 'Europe/Berlin'},
    'Chemnitz': {'lat': '50.8278', 'lon': '12.9214', 'tz': 'Europe/Berlin'},
    'Al-Khalil': {'lat': '31.5326', 'lon': '35.0998', 'tz': 'Asia/Hebron'},
  };

  Future<WeatherCityData> fetch(String city) async {
    final c = cities[city]!;
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': c['lat']!,
      'longitude': c['lon']!,
      'hourly': 'temperature_2m,precipitation_probability,weather_code,wind_speed_10m',
      'timezone': c['tz']!,
      'forecast_days': '2',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw Exception('Kunne ikke hente værdata');
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    final hourly = json['hourly'] as Map<String, dynamic>;
    final times = (hourly['time'] as List).map((x) => DateTime.parse(x as String)).toList();
    final temps = (hourly['temperature_2m'] as List).map((x) => (x as num).toDouble()).toList();
    final rain = (hourly['precipitation_probability'] as List).map((x) => (x as num).toInt()).toList();
    final codes = (hourly['weather_code'] as List).map((x) => (x as num).toInt()).toList();
    final wind = (hourly['wind_speed_10m'] as List).map((x) => (x as num).toDouble()).toList();
    return WeatherCityData(name: city, timezone: c['tz']!, times: times, temperatures: temps, precipitation: rain, codes: codes, wind: wind);
  }
}

String weatherIcon(int code) {
  if (code == 0) return '☀️';
  if (code <= 3) return '🌤️';
  if (code <= 48) return '🌫️';
  if (code <= 57) return '🌦️';
  if (code <= 67) return '🌧️';
  if (code <= 77) return '❄️';
  if (code <= 82) return '🌦️';
  if (code <= 86) return '🌨️';
  return '⛈️';
}

class WeatherPage extends StatefulWidget {
  const WeatherPage({super.key});
  @override State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  final service = WeatherService();
  late Future<List<WeatherCityData>> future;
  @override void initState() { super.initState(); _refresh(); }
  void _refresh() { future = Future.wait(WeatherService.cities.keys.map(service.fetch)); if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Vær'), actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh), tooltip: 'Oppdater')]),
    body: FutureBuilder<List<WeatherCityData>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off, size: 56), const SizedBox(height: 12), const Text('Kunne ikke hente værdata akkurat nå.'), const SizedBox(height: 12), FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.refresh), label: const Text('Prøv igjen'))])));
        return ListView(padding: const EdgeInsets.all(12), children: [
          const Padding(padding: EdgeInsets.only(left: 4, bottom: 10), child: Text('Time for time', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          ...snap.data!.map((city) => _cityCard(city)),
          const SizedBox(height: 8),
          const Text('Værdata leveres av Open-Meteo. Prognosen viser timeverdier og oppdateres når du trykker Oppdater.', style: TextStyle(fontSize: 12)),
        ]);
      },
    ),
  );

  Widget _cityCard(WeatherCityData city) {
    final now = DateTime.now();
    var start = city.times.indexWhere((t) => !t.isBefore(DateTime(now.year, now.month, now.day, now.hour)));
    if (start < 0) start = 0;
    final end = (start + 24).clamp(0, city.times.length);
    final current = start;
    return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.fromLTRB(14, 14, 8, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.location_on_outlined), const SizedBox(width: 6), Text(city.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const Spacer(), Text('${city.temperatures[current].round()} °C', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 4), Text('${weatherIcon(city.codes[current])}  Vind ${city.wind[current].round()} km/t • Nedbør ${city.precipitation[current]} %'),
      const SizedBox(height: 12),
      SizedBox(height: 112, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: end - start, itemBuilder: (_, offset) {
        final i = start + offset;
        return Container(width: 78, margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: Theme.of(context).dividerColor)), child: Column(children: [
          Text(DateFormat('HH:mm').format(city.times[i]), style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 4), Text(weatherIcon(city.codes[i]), style: const TextStyle(fontSize: 22)), Text('${city.temperatures[i].round()}°'), const SizedBox(height: 2), Text('${city.precipitation[i]}%', style: const TextStyle(fontSize: 11)),
        ]));
      })),
    ])));
  }
}
class NewsItem {
  final String title;
  final String source;
  final String url;
  final DateTime? published;
  NewsItem({required this.title, required this.source, required this.url, this.published});
}

class NewsService {
  Future<List<NewsItem>> fetch({String query = 'Norge Oslo'}) async {
    final uri = Uri.https('news.google.com', '/rss/search', {
      'q': '$query when:1d',
      'hl': 'no',
      'gl': 'NO',
      'ceid': 'NO:no',
    });
    final response = await http.get(uri, headers: {'User-Agent': 'MinSmartsekretaer/0.5'}).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw Exception('Kunne ikke hente nyheter');
    final xml = response.body;
    final items = <NewsItem>[];
    for (final m in RegExp(r'<item>(.*?)</item>', dotAll: true).allMatches(xml)) {
      final block = m.group(1)!;
      String tag(String name) {
        final x = RegExp('<$name(?: [^>]*)?>(.*?)</$name>', dotAll: true).firstMatch(block)?.group(1) ?? '';
        return _decodeXml(x.replaceAll(RegExp(r'<[^>]+>'), ' ').trim());
      }
      final title = tag('title');
      final link = RegExp(r'<link>(.*?)</link>', dotAll: true).firstMatch(block)?.group(1)?.trim() ?? '';
      final source = tag('source');
      final pub = tag('pubDate');
      if (title.isNotEmpty && link.isNotEmpty) {
        items.add(NewsItem(title: title, source: source.isEmpty ? 'Nyhetskilde' : source, url: link, published: DateTime.tryParse(pub)));
      }
    }
    return items.take(20).toList();
  }
  String _decodeXml(String s) => s.replaceAll('&amp;', '&').replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>');
}

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});
  @override State<NewsPage> createState() => _NewsPageState();
}
class _NewsPageState extends State<NewsPage> {
  final service = NewsService();
  late Future<List<NewsItem>> future;
  String query = 'Norge Oslo';
  @override void initState() { super.initState(); _refresh(); }
  void _refresh() { future = service.fetch(query: query); if (mounted) setState(() {}); }
  Future<void> _open(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nyheter'), actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh), tooltip: 'Oppdater')]),
    body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 10, 12, 4), child: Wrap(spacing: 8, children: [
        ChoiceChip(label: const Text('Norge'), selected: query == 'Norge', onSelected: (_) { query = 'Norge'; _refresh(); }),
        ChoiceChip(label: const Text('Oslo'), selected: query == 'Norge Oslo', onSelected: (_) { query = 'Norge Oslo'; _refresh(); }),
        ChoiceChip(label: const Text('Verden'), selected: query == 'Verden', onSelected: (_) { query = 'Verden'; _refresh(); }),
      ])),
      Expanded(child: FutureBuilder<List<NewsItem>>(future: future, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off, size: 52), const SizedBox(height: 10), const Text('Kunne ikke hente nyheter akkurat nå.'), const SizedBox(height: 10), FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.refresh), label: const Text('Prøv igjen'))])));
        final items = snap.data ?? [];
        if (items.isEmpty) return const Center(child: Text('Ingen nyheter funnet.'));
        return RefreshIndicator(onRefresh: () async { _refresh(); await future; }, child: ListView.separated(padding: const EdgeInsets.all(12), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
          final n = items[i];
          return Card(child: ListTile(isThreeLine: true, leading: CircleAvatar(child: Text('${i+1}')), title: Text(n.title), subtitle: Text('${n.source}\nTrykk for å lese saken'), onTap: () => _open(n.url)));
        }));
      }))
    ]),
  );
}
class MusicPage extends StatelessWidget{const MusicPage({super.key});@override Widget build(BuildContext context)=>_PlaceholderPage(title:'Musikk',icon:Icons.music_note,text:'Planlagt musikkavspilling og valg av spilleliste kobles til i neste utviklingstrinn.');}
class ActivityPage extends StatefulWidget{const ActivityPage({super.key});@override State<ActivityPage> createState()=>_ActivityPageState();}
class _ActivityPageState extends State<ActivityPage>{
  StreamSubscription<StepCount>? _stepsSub; StreamSubscription<PedestrianStatus>? _statusSub;
  int? steps; String status='Ukjent'; Position? position; String? error;
  static const double metersPerStep=0.75;
  @override void initState(){super.initState(); _startSteps();}
  @override void dispose(){_stepsSub?.cancel();_statusSub?.cancel();super.dispose();}
  Future<void> _startSteps() async{
    try{
      final stream=await Pedometer.stepCountStream;
      _stepsSub=stream.listen((e){if(mounted)setState(()=>steps=e.steps);},onError:(_){if(mounted)setState(()=>error='Skrittsensoren er ikke tilgjengelig på denne enheten.');});
      final ps=await Pedometer.pedestrianStatusStream;
      _statusSub=ps.listen((e){if(mounted)setState(()=>status=e.status=='walking'?'Går':'Står stille';)},onError:(_){if(mounted)setState(()=>status='Ukjent');});
    }catch(_){if(mounted)setState(()=>error='Skrittsensoren er ikke tilgjengelig på denne enheten.');}
  }
  Future<void> _locate() async{
    try{
      if(!await Geolocator.isLocationServiceEnabled()){setState(()=>error='Posisjonstjenester er slått av.');return;}
      var perm=await Geolocator.checkPermission();
      if(perm==LocationPermission.denied) perm=await Geolocator.requestPermission();
      if(perm==LocationPermission.denied||perm==LocationPermission.deniedForever){setState(()=>error='Posisjonstillatelse ble ikke gitt.');return;}
      final pos=await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      if(mounted)setState(()=>position=pos);
    }catch(_){if(mounted)setState(()=>error='Kunne ikke hente posisjonen.');}
  }
  Future<void> _openMap() async{
    if(position==null){await _locate();}
    final p=position; if(p==null)return;
    final uri=Uri.parse('https://www.google.com/maps/search/?api=1&query=${p.latitude},${p.longitude}');
    await launchUrl(uri,mode:LaunchMode.externalApplication);
  }
  @override Widget build(BuildContext context){
    final d=steps==null?0.0:steps!*metersPerStep/1000;
    return Scaffold(appBar:AppBar(title:const Text('Aktivitet & tur')),body:RefreshIndicator(onRefresh:()async{await _locate();},child:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[const Icon(Icons.directions_walk,size:56),const SizedBox(height:12),Text(steps==null?'—':'$steps',style:Theme.of(context).textTheme.displaySmall),const Text('skritt i dag'),const SizedBox(height:12),Text('${d.toStringAsFixed(2)} km beregnet distanse'),const SizedBox(height:8),Text('Status: $status')] ))),
      if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:TextStyle(color:Theme.of(context).colorScheme.error))),
      const SizedBox(height:12),
      Card(child:ListTile(leading:const Icon(Icons.my_location),title:Text(position==null?'Finn min posisjon':'Posisjon funnet'),subtitle:position==null?const Text('Trykk for å hente GPS-posisjon'):Text('${position!.latitude.toStringAsFixed(5)}, ${position!.longitude.toStringAsFixed(5)}'),onTap:_locate)),
      Card(child:ListTile(leading:const Icon(Icons.map),title:const Text('Åpne Google Maps'),subtitle:const Text('Vis min nåværende posisjon'),onTap:_openMap)),
      const SizedBox(height:8),
      const Text('Distanse er et estimat basert på 0,75 m per skritt. For mer presisjon kan steglengden tilpasses senere.'),
    ])));
  }
}
class _PlaceholderPage extends StatelessWidget{final String title,text;final IconData icon;const _PlaceholderPage({required this.title,required this.icon,required this.text});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title)),body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:56),const SizedBox(height:16),Text(text,textAlign:TextAlign.center,style:Theme.of(context).textTheme.titleMedium)])));}

class MorePage extends StatelessWidget{const MorePage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Mer')),body:ListView(children:[_open(context,Icons.calendar_month,'Kalender',const CalendarPage()),_open(context,Icons.notifications,'Påminnelser',const RemindersPage()),_open(context,Icons.cloud,'Vær',const WeatherPage()),_open(context,Icons.newspaper,'Nyheter',const NewsPage()),_open(context,Icons.music_note,'Musikk',const MusicPage()),_open(context,Icons.map,'Aktivitet & kart',const ActivityPage())]);}
Widget _open(BuildContext context,IconData icon,String title,Widget page)=>ListTile(leading:Icon(icon),title:Text(title),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>page)));
